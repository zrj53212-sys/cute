# AI场景记忆 · 英语单词（PWA）

可安装的渐进式网页应用，支持离线使用。

## 快速启动（本地）

在项目目录下运行任意一种本地服务器：

```bash
# Python 3（推荐）
python3 -m http.server 8080

# 或 Node.js
npx serve -p 8080
```

然后在浏览器打开：http://localhost:8080

## 安装为 App

### Android (Chrome)
1. 打开上述地址
2. 浏览器菜单 →「添加到主屏幕」或点击页面上的「📲 安装到主屏幕」按钮

### iPhone / iPad (Safari)
1. 用 Safari 打开
2. 点击分享按钮 →「添加到主屏幕」

### 桌面 Chrome / Edge
1. 地址栏右侧会出现安装图标
2. 或点击页面上的安装按钮

安装后可像原生 App 一样全屏运行，支持离线使用。

## 文件说明

- `index.html` — 主应用
- `manifest.json` — PWA 清单
- `sw.js` — Service Worker（离线缓存）
- `icon-192.png` / `icon-512.png` — 应用图标
